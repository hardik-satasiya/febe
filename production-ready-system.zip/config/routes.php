<?php

// Route::get('/', function () {
//     return view('welcome');
// });


/*Route::post('{Controller}/{action}', function($controller, $action){
	    $app = app();
	    $controller = $app->make('\\HS\\Controllers\\'. ucfirst($controller) . 'Controller');
	    return $controller->callAction($action, $parameters = array());

});

Route::get('{Controller}/{action}', function($controller, $action){
	    $app = app();
	    $controller = $app->make('\\HS\\Controllers\\'. ucfirst($controller) . 'Controller');
	    return $controller->callAction($action, $parameters = array());

});*/

