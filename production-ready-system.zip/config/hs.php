<?php

return [
    'backendUri' => 'admin',
];
