<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Exception</title>
        <link href="<?= Url::asset(config('app.modulesUrl') . '/system/assets/css/styles.css') ?>" rel="stylesheet">
        <script src="<?= Url::asset(config('app.modulesUrl') . '/system/assets/vendor/syntaxhighlighter/scripts/shCore.js') ?>"></script>
        <script src="<?= Url::asset(config('app.modulesUrl') . '/system/assets/vendor/syntaxhighlighter/scripts/shBrushPhp.js') ?>"></script>
        <script src="<?= Url::asset(config('app.modulesUrl') . '/system/assets/vendor/syntaxhighlighter/scripts/shBrushXml.js') ?>"></script>
        <link href="<?= Url::asset(config('app.modulesUrl') . '/system/assets/vendor/syntaxhighlighter/styles/shCore.css') ?>">
    </head>
    <body>

        <div class="container">
            <h1><i class="icon-power-off warning"></i> Hello, Welcome</h1>
        </div>

    </body>
</html>